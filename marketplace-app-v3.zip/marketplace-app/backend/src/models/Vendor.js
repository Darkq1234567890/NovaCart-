import mongoose from 'mongoose';
const vendorSchema=new mongoose.Schema({
  user:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true,unique:true},storeName:{type:String,required:true,trim:true},description:String,
  status:{type:String,enum:['pending','approved','suspended'],default:'pending'},address:String
},{timestamps:true});
export default mongoose.model('Vendor',vendorSchema);
