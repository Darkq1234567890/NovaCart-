import mongoose from 'mongoose';
const itemSchema=new mongoose.Schema({
  product:{type:mongoose.Schema.Types.ObjectId,ref:'Product',required:true},
  vendor:{type:mongoose.Schema.Types.ObjectId,ref:'Vendor',required:true},
  name:String,quantity:{type:Number,min:1,required:true},price:{type:Number,min:0,required:true}
},{_id:false});
const orderSchema=new mongoose.Schema({
  buyer:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true},
  items:{type:[itemSchema],required:true},total:{type:Number,required:true,min:0},
  status:{type:String,enum:['pending','confirmed','shipped','delivered','cancelled'],default:'pending'},
  paymentStatus:{type:String,enum:['pending','paid','failed','refunded'],default:'pending'},
  stripeSessionId:String,stripePaymentIntentId:String,paidAt:Date,
  shippingAddress:{type:String,required:true}
},{timestamps:true});
export default mongoose.model('Order',orderSchema);
