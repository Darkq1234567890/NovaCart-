import mongoose from 'mongoose';
const ticketSchema=new mongoose.Schema({user:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true},subject:{type:String,required:true},message:{type:String,required:true},status:{type:String,enum:['open','in_progress','resolved','closed'],default:'open'},priority:{type:String,enum:['low','normal','high','urgent'],default:'normal'},assignedTo:{type:mongoose.Schema.Types.ObjectId,ref:'User'}},{timestamps:true});
export default mongoose.model('SupportTicket',ticketSchema);
