'use client';
import {useEffect,useState} from 'react';
import Header from '../components/Header';
import ProductCard from '../components/ProductCard';
import {api} from '../lib';
export default function Home(){const [products,setProducts]=useState([]),[q,setQ]=useState(''),[loading,setLoading]=useState(true);useEffect(()=>{api('/products').then(setProducts).catch(()=>setProducts([])).finally(()=>setLoading(false))},[]);const filtered=products.filter(p=>`${p.name} ${p.description||''} ${p.category||''}`.toLowerCase().includes(q.toLowerCase()));return <><Header/><main className="container"><section className="hero"><div><span className="pill">Multi-vendor marketplace</span><h1>Shop from independent vendors.</h1><p>Browse products, add them to your cart, and securely prepay through Stripe Checkout.</p></div><input className="search" value={q} onChange={e=>setQ(e.target.value)} placeholder="Search products..."/></section>{loading?<p>Loading products…</p>:<div className="productGrid">{filtered.map(p=><ProductCard key={p._id} product={p}/>)}</div>}{!loading&&!filtered.length&&<div className="empty">No products found.</div>}</main></>}
