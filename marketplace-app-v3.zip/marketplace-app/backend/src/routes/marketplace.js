import {Router} from 'express';
import mongoose from 'mongoose';
import {auth,roles} from '../middleware/auth.js';
import Product from '../models/Product.js';
import Vendor from '../models/Vendor.js';
import Order from '../models/Order.js';
import Payout from '../models/Payout.js';
import User from '../models/User.js';
import SupportTicket from '../models/SupportTicket.js';

const r=Router();
const oid=id=>mongoose.Types.ObjectId.isValid(id)?new mongoose.Types.ObjectId(id):null;
async function myVendor(userId){return Vendor.findOne({user:userId});}

// Dashboard summaries
r.get('/dashboard/admin',auth,roles('admin'),async(req,res)=>{
 const [users,products,orders,vendors,payouts,tickets]=await Promise.all([
  User.countDocuments(),Product.countDocuments(),Order.countDocuments(),Vendor.countDocuments(),Payout.countDocuments({status:{$in:['requested','processing']}}),SupportTicket.countDocuments({status:{$in:['open','in_progress']}})
 ]);
 const revenue=(await Order.aggregate([{$match:{status:{$nin:['cancelled']} }},{$group:{_id:null,total:{$sum:'$total'}}}]))[0]?.total||0;
 res.json({users,products,orders,vendors,pendingPayouts:payouts,openTickets:tickets,revenue});
});

r.get('/dashboard/vendor',auth,roles('seller'),async(req,res)=>{
 const v=await myVendor(req.user._id); if(!v)return res.status(404).json({error:'Vendor profile not found'});
 const [products,orders,payouts]=await Promise.all([
  Product.countDocuments({vendor:v._id}),
  Order.find({'items.vendor':v._id}).sort({createdAt:-1}).limit(10).populate('buyer','name email'),
  Payout.find({vendor:v._id}).sort({createdAt:-1}).limit(10)
 ]);
 const agg=await Order.aggregate([{$match:{'items.vendor':v._id,status:{$nin:['cancelled']}}},{$unwind:'$items'},{$match:{'items.vendor':v._id}},{$group:{_id:null,gross:{$sum:{$multiply:['$items.price','$items.quantity']}}}}]);
 res.json({vendor:v,productCount:products,orders,payouts,grossSales:agg[0]?.gross||0});
});

// Vendor self-service product CRUD
r.get('/vendor/products',auth,roles('seller'),async(req,res)=>{const v=await myVendor(req.user._id);if(!v)return res.status(404).json({error:'Vendor profile not found'});res.json(await Product.find({vendor:v._id}).sort({createdAt:-1}));});
r.post('/vendor/products',auth,roles('seller'),async(req,res)=>{const v=await myVendor(req.user._id);if(!v)return res.status(404).json({error:'Vendor profile not found'});const p=await Product.create({...req.body,vendor:v._id});res.status(201).json(p);});
r.put('/vendor/products/:id',auth,roles('seller'),async(req,res)=>{const v=await myVendor(req.user._id);const p=await Product.findOneAndUpdate({_id:req.params.id,vendor:v?._id},req.body,{new:true,runValidators:true});if(!p)return res.status(404).json({error:'Product not found'});res.json(p);});
r.delete('/vendor/products/:id',auth,roles('seller'),async(req,res)=>{const v=await myVendor(req.user._id);const p=await Product.findOneAndDelete({_id:req.params.id,vendor:v?._id});if(!p)return res.status(404).json({error:'Product not found'});res.json({message:'Deleted'});});

// Vendor order tracking
r.get('/vendor/orders',auth,roles('seller'),async(req,res)=>{const v=await myVendor(req.user._id);if(!v)return res.status(404).json({error:'Vendor profile not found'});res.json(await Order.find({'items.vendor':v._id}).sort({createdAt:-1}).populate('buyer','name email'));});
r.put('/vendor/orders/:id/status',auth,roles('seller'),async(req,res)=>{const v=await myVendor(req.user._id);if(!v)return res.status(404).json({error:'Vendor profile not found'});const allowed=['confirmed','shipped','delivered','cancelled'];if(!allowed.includes(req.body.status))return res.status(400).json({error:'Invalid status'});const order=await Order.findOne({_id:req.params.id,'items.vendor':v._id});if(!order)return res.status(404).json({error:'Order not found'});order.status=req.body.status;await order.save();res.json(order);});

// Vendor payouts
r.get('/vendor/payouts',auth,roles('seller'),async(req,res)=>{const v=await myVendor(req.user._id);if(!v)return res.status(404).json({error:'Vendor profile not found'});res.json(await Payout.find({vendor:v._id}).sort({createdAt:-1}));});
r.post('/vendor/payouts',auth,roles('seller'),async(req,res)=>{const v=await myVendor(req.user._id);if(!v)return res.status(404).json({error:'Vendor profile not found'});const amount=Number(req.body.amount);if(!amount||amount<=0)return res.status(400).json({error:'Valid amount is required'});const p=await Payout.create({vendor:v._id,amount,note:req.body.note});res.status(201).json(p);});

// Admin payout/vendor controls
r.get('/admin/payouts',auth,roles('admin'),async(req,res)=>res.json(await Payout.find().sort({createdAt:-1}).populate({path:'vendor',populate:{path:'user',select:'name email'}})));
r.put('/admin/payouts/:id',auth,roles('admin'),async(req,res)=>{const allowed=['requested','processing','paid','rejected'];if(!allowed.includes(req.body.status))return res.status(400).json({error:'Invalid status'});const data={status:req.body.status,reference:req.body.reference,note:req.body.note};if(req.body.status==='paid')data.processedAt=new Date();const p=await Payout.findByIdAndUpdate(req.params.id,data,{new:true,runValidators:true});if(!p)return res.status(404).json({error:'Payout not found'});res.json(p);});
r.get('/admin/vendors',auth,roles('admin'),async(req,res)=>res.json(await Vendor.find().populate('user','name email phone').sort({createdAt:-1})));
r.put('/admin/vendors/:id/status',auth,roles('admin'),async(req,res)=>{if(!['pending','approved','suspended'].includes(req.body.status))return res.status(400).json({error:'Invalid status'});const v=await Vendor.findByIdAndUpdate(req.params.id,{status:req.body.status},{new:true});if(!v)return res.status(404).json({error:'Vendor not found'});res.json(v);});
r.get('/admin/users',auth,roles('admin'),async(req,res)=>res.json(await User.find().select('-passwordHash').sort({createdAt:-1})));
r.put('/admin/users/:id/status',auth,roles('admin'),async(req,res)=>{const u=await User.findByIdAndUpdate(req.params.id,{isActive:!!req.body.isActive},{new:true}).select('-passwordHash');if(!u)return res.status(404).json({error:'User not found'});res.json(u);});
r.get('/admin/orders',auth,roles('admin'),async(req,res)=>res.json(await Order.find().sort({createdAt:-1}).populate('buyer','name email').populate('items.product','name').populate('items.vendor','storeName')));

export default r;
