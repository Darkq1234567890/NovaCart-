export const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';
export const money = n => `₹${Number(n || 0).toLocaleString('en-IN')}`;
export function getUser(){ if(typeof window==='undefined') return null; try{return JSON.parse(localStorage.getItem('user')||'null')}catch{return null} }
export function getToken(){ return typeof window==='undefined' ? '' : localStorage.getItem('token') || ''; }
export async function api(path, options={}){
  const headers={ ...(options.body instanceof FormData ? {} : {'Content-Type':'application/json'}), ...(options.headers||{}), Authorization:`Bearer ${getToken()}` };
  const r=await fetch(`${API}${path}`,{...options,headers});
  const data=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.error||'Request failed');
  return data;
}
export function cartKey(){return 'marketplace_cart'}
export function readCart(){if(typeof window==='undefined')return [];try{return JSON.parse(localStorage.getItem(cartKey())||'[]')}catch{return []}}
export function saveCart(cart){localStorage.setItem(cartKey(),JSON.stringify(cart));window.dispatchEvent(new Event('cart-updated'))}
