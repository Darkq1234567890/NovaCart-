import {Router} from 'express';import {auth,roles} from '../middleware/auth.js';import Product from '../models/Product.js';import Vendor from '../models/Vendor.js';import Order from '../models/Order.js';import SupportTicket from '../models/SupportTicket.js';
const router=Router();
const crud=(path,Model,{createRoles=['admin'],updateRoles=['admin'],deleteRoles=['admin']}={})=>{
 const r=Router();r.get('/',auth,async(req,res)=>res.json(await Model.find().populate('user buyer vendor assignedTo','name email storeName')));
 r.get('/:id',auth,async(req,res)=>{const x=await Model.findById(req.params.id).populate('user buyer vendor assignedTo','name email storeName');if(!x)return res.status(404).json({error:'Not found'});res.json(x)});
 r.post('/',auth,roles(...createRoles),async(req,res)=>res.status(201).json(await Model.create(req.body)));
 r.put('/:id',auth,roles(...updateRoles),async(req,res)=>{const x=await Model.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true});if(!x)return res.status(404).json({error:'Not found'});res.json(x)});
 r.delete('/:id',auth,roles(...deleteRoles),async(req,res)=>{const x=await Model.findByIdAndDelete(req.params.id);if(!x)return res.status(404).json({error:'Not found'});res.json({message:'Deleted'})});return [path,r];
};
const [p,pr]=crud('/products',Product,{createRoles:['admin'],updateRoles:['admin'],deleteRoles:['admin']});router.use(p,pr);
const [v,vr]=crud('/vendors',Vendor,{createRoles:['admin'],updateRoles:['admin'],deleteRoles:['admin']});router.use(v,vr);
const [o,or]=crud('/orders',Order,{createRoles:['admin'],updateRoles:['admin'],deleteRoles:['admin']});router.use(o,or);
const [t,tr]=crud('/tickets',SupportTicket,{createRoles:['admin','buyer','seller'],updateRoles:['admin'],deleteRoles:['admin']});router.use(t,tr);
export default router;
