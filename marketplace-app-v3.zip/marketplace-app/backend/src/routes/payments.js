import { Router } from 'express';
import mongoose from 'mongoose';
import Stripe from 'stripe';
import { auth, roles } from '../middleware/auth.js';
import Product from '../models/Product.js';
import Order from '../models/Order.js';

const r = Router();
const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;

function requireStripe(res) {
  if (!stripe) {
    res.status(503).json({ error: 'Stripe is not configured. Set STRIPE_SECRET_KEY on the backend.' });
    return false;
  }
  return true;
}

// Creates the marketplace order from server-side product prices, then creates a Stripe-hosted Checkout Session.
r.post('/checkout', auth, roles('buyer'), async (req, res) => {
  if (!requireStripe(res)) return;
  const { items, shippingAddress } = req.body;
  if (!Array.isArray(items) || !items.length || !shippingAddress?.trim()) {
    return res.status(400).json({ error: 'items and shippingAddress are required' });
  }

  const cleanItems = items.map(item => ({
    product: item.product,
    quantity: Number(item.quantity)
  }));
  if (cleanItems.some(i => !mongoose.Types.ObjectId.isValid(i.product) || !Number.isInteger(i.quantity) || i.quantity < 1 || i.quantity > 100)) {
    return res.status(400).json({ error: 'Invalid cart items' });
  }

  const products = await Product.find({
    _id: { $in: cleanItems.map(i => i.product) },
    isActive: true
  }).populate('vendor');
  if (products.length !== cleanItems.length) return res.status(400).json({ error: 'One or more products are unavailable' });

  const byId = new Map(products.map(p => [String(p._id), p]));
  const orderItems = [];
  const lineItems = [];
  let total = 0;

  for (const item of cleanItems) {
    const p = byId.get(String(item.product));
    if (!p || !p.vendor || p.vendor.status !== 'approved') return res.status(400).json({ error: `Product ${item.product} is not currently sellable` });
    if (p.stock < item.quantity) return res.status(409).json({ error: `${p.name} has only ${p.stock} item(s) left` });
    const lineTotal = p.price * item.quantity;
    total += lineTotal;
    orderItems.push({ product: p._id, vendor: p.vendor._id, name: p.name, quantity: item.quantity, price: p.price });
    lineItems.push({
      price_data: {
        currency: process.env.STRIPE_CURRENCY || 'inr',
        product_data: { name: p.name, description: p.description?.slice(0, 500) || undefined },
        unit_amount: Math.round(p.price * 100)
      },
      quantity: item.quantity
    });
  }

  const order = await Order.create({
    buyer: req.user._id,
    items: orderItems,
    total,
    shippingAddress: shippingAddress.trim(),
    paymentStatus: 'pending'
  });

  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items: lineItems,
      success_url: `${process.env.CLIENT_URL || 'http://localhost:3000'}/checkout/success?orderId=${order._id}&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.CLIENT_URL || 'http://localhost:3000'}/cart?cancelled=1`,
      customer_email: req.user.email,
      metadata: { orderId: String(order._id), buyerId: String(req.user._id) }
    });
    order.stripeSessionId = session.id;
    await order.save();
    return res.status(201).json({ orderId: order._id, checkoutUrl: session.url });
  } catch (err) {
    await Order.findByIdAndDelete(order._id);
    throw err;
  }
});

r.get('/orders/:id', auth, roles('buyer'), async (req, res) => {
  const order = await Order.findOne({ _id: req.params.id, buyer: req.user._id });
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json(order);
});

// Stripe requires the raw request body for signature verification, so this route is mounted before express.json().
export async function stripeWebhook(req, res) {
  if (!requireStripe(res)) return;
  const signature = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, signature, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed' || event.type === 'checkout.session.async_payment_succeeded') {
    const session = event.data.object;
    const orderId = session.metadata?.orderId;
    if (orderId) {
      const order = await Order.findById(orderId);
      if (order && order.paymentStatus !== 'paid') {
        order.paymentStatus = 'paid';
        order.paidAt = new Date();
        order.stripePaymentIntentId = session.payment_intent || undefined;
        await order.save();

        // Decrement stock only after Stripe confirms payment.
        for (const item of order.items) {
          await Product.updateOne(
            { _id: item.product, stock: { $gte: item.quantity } },
            { $inc: { stock: -item.quantity } }
          );
        }
      }
    }
  }

  if (event.type === 'checkout.session.expired') {
    const session = event.data.object;
    if (session.metadata?.orderId) await Order.findByIdAndUpdate(session.metadata.orderId, { paymentStatus: 'failed' });
  }

  res.json({ received: true });
}

export default r;
