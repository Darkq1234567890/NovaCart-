'use client';
import Link from 'next/link';
import {useEffect,useState} from 'react';
import {getUser,readCart} from '../lib';
export default function Header(){const [user,setUser]=useState(null),[count,setCount]=useState(0);useEffect(()=>{const sync=()=>{setUser(getUser());setCount(readCart().reduce((s,x)=>s+x.quantity,0))};sync();addEventListener('cart-updated',sync);return()=>removeEventListener('cart-updated',sync)},[]);return <header className="topbar"><Link href="/" className="brand">MarketHub</Link><nav><Link href="/">Shop</Link><Link href="/cart">Cart ({count})</Link>{user?.role==='seller'&&<Link href="/vendor">Vendor</Link>}{user?.role==='admin'&&<Link href="/dashboard">Admin</Link>}{user?<button className="linkButton" onClick={()=>{localStorage.clear();location.href='/'}}>Logout</button>:<><Link href="/login">Login</Link><Link href="/register">Register</Link></>}</nav></header>}
