# MarketHub — Next.js + Express + MongoDB Atlas + Stripe

## Features
- Buyer storefront and local cart
- Vendor dashboard for products, orders and payout requests
- Existing admin dashboard from v2
- JWT role-based access control
- Stripe-hosted Checkout for prepaid orders
- Server-side price validation
- Stripe webhook verification and payment status updates
- Inventory decremented only after successful payment webhook

## Setup

### 1. Backend
```bash
cd backend
npm install
cp .env.example .env
npm run dev
```
Set:
```env
MONGODB_URI=mongodb+srv://...
JWT_SECRET=use-a-long-random-secret
CLIENT_URL=http://localhost:3000
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_CURRENCY=inr
```

### 2. Frontend
```bash
cd frontend
npm install
cp .env.local.example .env.local
npm run dev
```
Open `http://localhost:3000`.

### 3. Stripe webhook locally
Install and authenticate the Stripe CLI, then:
```bash
stripe listen --forward-to localhost:5000/api/payments/webhook
```
Copy the displayed `whsec_...` into `STRIPE_WEBHOOK_SECRET` and restart the backend.

For production, register an HTTPS webhook endpoint at:
`https://YOUR-API-DOMAIN/api/payments/webhook`

Listen for at least:
- `checkout.session.completed`
- `checkout.session.async_payment_succeeded`
- `checkout.session.expired`

The webhook, not the browser redirect, is the source of truth for payment confirmation.

## Payment flow
1. Buyer adds products to the cart.
2. Buyer enters shipping address.
3. Next.js calls `POST /api/payments/checkout`.
4. Express loads products from MongoDB and calculates the total from database prices.
5. Express creates the order with `paymentStatus=pending`.
6. Express creates a Stripe Checkout Session and returns the hosted Checkout URL.
7. Buyer pays on Stripe.
8. Stripe sends the signed webhook to Express.
9. Express marks the order `paid` and decrements stock.
10. Vendor sees the paid order in the vendor dashboard.

Never put `STRIPE_SECRET_KEY` in Next.js `NEXT_PUBLIC_*` variables.
