import mongoose from 'mongoose';
const payoutSchema = new mongoose.Schema({
  vendor:{type:mongoose.Schema.Types.ObjectId,ref:'Vendor',required:true},
  amount:{type:Number,required:true,min:0},
  status:{type:String,enum:['requested','processing','paid','rejected'],default:'requested'},
  reference:String,
  note:String,
  processedAt:Date
},{timestamps:true});
export default mongoose.model('Payout',payoutSchema);
