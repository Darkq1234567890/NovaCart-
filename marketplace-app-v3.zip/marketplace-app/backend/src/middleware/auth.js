import jwt from 'jsonwebtoken';
import User from '../models/User.js';
export async function auth(req,res,next){
  try{const h=req.headers.authorization;if(!h?.startsWith('Bearer ')) return res.status(401).json({error:'Authentication required'});const token=h.slice(7);const p=jwt.verify(token,process.env.JWT_SECRET);req.user=await User.findById(p.id).select('-passwordHash');if(!req.user||!req.user.isActive)return res.status(401).json({error:'Invalid user'});next();}catch(e){return res.status(401).json({error:'Invalid or expired token'});}
}
export function roles(...allowed){return (req,res,next)=>allowed.includes(req.user.role)?next():res.status(403).json({error:'Forbidden'});}
