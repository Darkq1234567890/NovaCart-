'use client';
import {useEffect,useState} from 'react';
import {useSearchParams} from 'next/navigation';
import Header from '../../../components/Header';
import {api,money} from '../../../lib';
export default function Success(){const params=useSearchParams(),[order,setOrder]=useState(null),[error,setError]=useState('');useEffect(()=>{const id=params.get('orderId');if(id)api(`/payments/orders/${id}`).then(setOrder).catch(e=>setError(e.message))},[params]);return <><Header/><main className="container narrow"><div className="success"><div className="check">✓</div><h1>Checkout submitted</h1><p>Your order was created. Stripe's webhook will confirm the payment before the order is treated as paid.</p>{order&&<div className="card"><p><b>Order:</b> {order._id}</p><p><b>Total:</b> {money(order.total)}</p><p><b>Payment:</b> {order.paymentStatus}</p></div>}{error&&<p className="error">{error}</p>}<a className="button" href="/">Continue shopping</a></div></main></>}
